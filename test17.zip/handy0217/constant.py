#-*- coding: UTF-8 -*-
from calamari_web.settings import SUPER_USER_PERMISSIONS as _SUPER_USER_PERMISSIONS

PERMISSION_CUST = {
    'operate_host': u'主机管理',
    'operate_topo': u'集群视图',
    'operate_pool': u'Pool管理',
    'operate_pool_rbd': u'块存储',
    'operate_pool_objs': u'对象存储',
    'operat_tenant': u'租户管理',
    'operat_bucket': u'容器管理',
    'operate_monitor': u'监控报表',
    'operate_alarm': u'实时告警',
    'operate_alarm_config': u'告警设置',
    'operate_operationlog': u'操作日志',
    'operate_syslog': u'系统日志',
    'operate_highavailable': u'高可用',
    'operate_files':u'文件存储',
    'operate_paramConfig': u'参数配置',
    'operate_readonly': u'只读',
    'operate_backup_cfg': u'拓扑配置',
    'operate_backup_policy': u'同步管理',
    'operate_partition': u'资源管理',
    'operate_snmp': u'SNMP设置',
    'operate_multi_cluster': u'多集群管理',
    'operate_auditlog': u'审计日志'
}

DEFAULT_GROUP = ''
USER_DEFAULT_PASSWORD = '123456'
SUPER_USER_PERMISSIONS = _SUPER_USER_PERMISSIONS
#用户组和用户组错误信息
USERGROUP_IS_EXIST = u'用户组已经存在'
USERGROUPNAME_IS_REQUIRED = u'用户组名不能为空'
USERGROUP_COUNT_REMOVE = u'删除失败，用户组中存在用户'
USERGROUP_DOEST_EXITST = u'用户组不存在'
USERNAME_OR_GROUPNAME_IS_REQUIRED = u'没有用户名或用户组名'
CANT_CHANGE_ROOT_GROUP = u'无法修改超级管理员所在组'

COUNTRYS = ["中国",           "丹麦",                "乌克兰",      "乌拉圭",                 "也门",           "以色列",
              "伊拉克",         "俄罗斯",               "保加利亚",    "克罗地亚",                "冰岛",          "利比亚",
              "加拿大",         "匈牙利",               "南非",       "卡塔尔",                  "卢森堡",          "印度",
              "印度尼西亚",      "危地马拉",             "厄瓜多尔",    "叙利亚",                  "台湾地区",     "哥伦比亚",
              "哥斯达黎加",       "土耳其",             "埃及",       "塞尔维亚共和国",            "黑山共和国",      "塞浦路斯",
              "墨西哥",       "多米尼加共和国",          "奥地利",     "委内瑞拉",                 "尼加拉瓜",       "巴拉圭",
              "巴拿马",          "巴林",               "巴西",        "希腊",                    "德国",            "意大利",
              "拉脱维亚",         "挪威",               "捷克共和国",   "摩洛哥",                  "斯洛伐克",      "斯洛文尼亚",
              "新加坡",          "新西兰",              "日本",        "智利",                    "比利时",        "沙特阿拉伯",
              "法国",           "波兰",                "波多黎哥",       "泰国",           "洪都拉斯",
              "澳大利亚",       "爱尔兰",               "爱沙尼亚",     "玻利维亚",                "瑞典",             "瑞士",
              "白俄罗斯",       "科威特",                "秘鲁",       "突尼斯",                  "立陶宛",            "约旦",
              "罗马尼亚",        "美国",                 "芬兰",       "苏丹",                    "英国",             "荷兰",
              "菲律宾",         "萨尔瓦多",              "葡萄牙",      "西班牙",                  "越南",           "阿尔及利亚",
              "阿尔巴尼亚",    "阿拉伯联合酋长国",         "阿曼",       "阿根廷",                   "韩国",          "香港",
              "马其顿王国",    "马来西亚",                 "马耳他",     "黎巴嫩","China", "Denmark", "Ukraine", "Uruguay", "Yemen", "Israel",
        "Iraq", "Russia", "Bulgaria", "Croatia", "Iceland", "Libya",
        "Canada", "Hungary", "South Africa", "Qatar", "Luxembourg", "India",
        "Indonesia", "Guatemala", "Ecuador", "Syria", "Taiwan", "Columbia",
        "Costa Rica", "Turkey", "Egypt", "Republic of Serbia", "Montenegro", "Cyprus",
        "Mexico", "The Dominican Republic", "Austria", "Venezuela", "Nicaragua", "Paraguay",
        "Panama", "Bahrain", "Brazil", "Greece", "Germany", "Italy",
        "Latvia", "Norway", "The Czech Republic", "Morocco", "Slovakia", "Slovenia",
        "Singapore", "New Zealand", "Japan", "Chile", "Belgium", "Saudi Arabia",
        "France", "Poland", "Puerto Rico", "Thailand", "Honduras",
        "Australia", "Ireland", "Estonia", "Bolivia", "Sweden", "Switzerland",
        "Belarus", "Kuwait", "Peru", "Tunisia", "Lithuania", "Jordan",
        "Romania", "United States", "Finland", "Sudan", "United Kingdom", "Netherlands",
        "Philippines", "El Salvador", "Portugal", "Spain", "Vietnam", "Algeria",
        "Albania", "The United Arab Emirates", "Oman", "Argentina", "South Korea", "Hong Kong",
        "Macedonia", "Malaysia", "Malta", "Lebanon"]
