define(['com', 'text!app/html/object_advance.html', 'css!app/css/object_advance.css'], function (c, dom) {
    var o = {
        index:0,
        actionList:[
            {'text':'s3:AbortMultipartUpload','value':'s3:AbortMultipartUpload'},
            {'text':'s3:CreateBucket','value':'s3:CreateBucket'},
            {'text':'s3:DeleteBucketPolicy','value':'s3:DeleteBucketPolicy'},
            {'text':'s3:DeleteBucket','value':'s3:DeleteBucket'},
            {'text':'s3:DeleteBucketWebsite','value':'s3:DeleteBucketWebsite'},
            {'text':'s3:DeleteObject','value':'s3:DeleteObject'},
            {'text':'s3:DeleteObjectVersion','value':'s3:DeleteObjectVersion'},
            {'text':'s3:DeleteReplicationConfiguration','value':'s3:DeleteReplicationConfiguration'},
            {'text':'s3:GetAccelerateConfiguration','value':'s3:GetAccelerateConfiguration'},
            {'text':'s3:GetBucketAcl','value':'s3:GetBucketAcl'},
            {'text':'s3:GetBucketCORS','value':'s3:GetBucketCORS'},
            {'text':'s3:GetBucketLocation','value':'s3:GetBucketLocation'},
            {'text':'s3:GetBucketLogging','value':'s3:GetBucketLogging'},
            {'text':'s3:GetBucketNotification','value':'s3:GetBucketNotification'},
            {'text':'s3:GetBucketPolicy','value':'s3:GetBucketPolicy'},
            {'text':'s3:GetBucketRequestPayment','value':'s3:GetBucketRequestPayment'},
            {'text':'s3:GetBucketTagging','value':'s3:GetBucketTagging'},
            {'text':'s3:GetBucketVersioning','value':'s3:GetBucketVersioning'},
            {'text':'s3:GetBucketWebsite','value':'s3:GetBucketWebsite'},
            {'text':'s3:GetLifecycleConfiguration','value':'s3:GetLifecycleConfiguration'},
            {'text':'s3:GetObjectAcl','value':'s3:GetObjectAcl'},
            {'text':'s3:GetObject','value':'s3:GetObject'},
            {'text':'s3:GetObjectTorrent','value':'s3:GetObjectTorrent'},
            {'text':'s3:GetObjectVersionAcl','value':'s3:GetObjectVersionAcl'},
            {'text':'s3:GetObjectVersion','value':'s3:GetObjectVersion'},
            {'text':'s3:GetObjectVersionTorrent','value':'s3:GetObjectVersionTorrent'},
            {'text':'s3:GetReplicationConfiguration','value':'s3:GetReplicationConfiguration'},
            {'text':'s3:ListAllMyBuckets','value':'s3:ListAllMyBuckets'},
            {'text':'s3:ListBucketMultiPartUploads','value':'s3:ListBucketMultiPartUploads'},
            {'text':'s3:ListBucket','value':'s3:ListBucket'},
            {'text':'s3:ListBucketVersions','value':'s3:ListBucketVersions'},
            {'text':'s3:ListMultipartUploadParts','value':'s3:ListMultipartUploadParts'},
            {'text':'s3:PutAccelerateConfiguration','value':'s3:PutAccelerateConfiguration'},
            {'text':'s3:PutBucketAcl','value':'s3:PutBucketAcl'},
            {'text':'s3:PutBucketCORS','value':'s3:PutBucketCORS'},
            {'text':'s3:PutBucketLogging','value':'s3:PutBucketLogging'},
            {'text':'s3:PutBucketNotification','value':'s3:PutBucketNotification'},
            {'text':'s3:PutBucketPolicy','value':'s3:PutBucketPolicy'},
            {'text':'s3:PutBucketRequestPayment','value':'s3:PutBucketRequestPayment'},
            {'text':'s3:PutBucketTagging','value':'s3:PutBucketTagging'},
            {'text':'s3:PutBucketVersioning','value':'s3:PutBucketVersioning'},
            {'text':'s3:PutBucketWebsite','value':'s3:PutBucketWebsite'},
            {'text':'s3:PutLifecycleConfiguration','value':'s3:PutLifecycleConfiguration'},
            {'text':'s3:PutObjectAcl','value':'s3:PutObjectAcl'},
            {'text':'s3:PutObject','value':'s3:PutObject'},
            {'text':'s3:PutObjectVersionAcl','value':'s3:PutObjectVersionAcl'},
            {'text':'s3:PutReplicationConfiguration','value':'s3:PutReplicationConfiguration'},
            {'text':'s3:RestoreObject','value':'s3:RestoreObject'},
        ],
        CKey:[
            {'text':'aws:CurrentTime','value':'aws:CurrentTime'},
            {'text':'aws:EpochTime','value':'aws:EpochTime'},
            {'text':'aws:PrincipalType','value':'aws:PrincipalType'},
            {'text':'aws:Referer','value':'aws:Referer'},
            {'text':'aws:SecureTransport','value':'aws:SecureTransport'},
            {'text':'aws:SourceIp','value':'aws:SourceIp'},
            {'text':'aws:UserAgent','value':'aws:UserAgent'},
            {'text':'aws:username','value':'aws:username'},
        ],
        CType:{
            'aws:CurrentTime':[{'text':'DateEquals','value':'DateEquals'},{'text':'DateNotEquals','value':'DateNotEquals'}],
            'aws:EpochTime':[{'text':'NumericEquals','value':'NumericEquals'},{'text':'NumericNotEquals','value':'NumericNotEquals'}],
            'aws:PrincipalType':[{'text':'StringEquals','value':'StringEquals'},{'text':'StringNotEquals','value':'StringNotEquals'}],
            'aws:SecureTransport':[{'text':'Bool','value':'Bool'}],
            'aws:SourceIp':[{'text':'IpAddress','value':'IpAddress'},{'text':'NotIpAddress','value':'NotIpAddress'}]
        },
        load:function(){
            // o.handleIcon();
        },
        getAdvanceSettingDom: function (target, pgridList) {
            var clientDom = $(dom).filter('.advance-setting').attr('id', 'bucket_advance');
            target.after(clientDom);
            clientDom.children('header').on('click', function (e) {
                var parent = $(this).parent();
                var curHeight = parent.height(), toHeight = 0;
                parent.css('height', curHeight + 'px');
                if (curHeight <= 26) {//show
                    parent.children().each(function (i, e) {
                        toHeight += $(e).height();
                    });
                    toHeight += 15;
                    if ($('.setting-pop').length) {
                        if (toHeight < 153) toHeight = 153;
                    }
                    $('li[data-value="worm"]').removeClass('displayNone');
                    $('li[data-value="copy"]').removeClass('displayNone');
                    $('li[data-value="remote"]').removeClass('displayNone');
                    $('li[data-value="keepTime"]').removeClass('displayNone');
                    $('li[data-value="capitcy"]').removeClass('displayNone');
                    $('li[data-value="quota"]').removeClass('displayNone');
                    $('li[data-value="capitcyQuota"]').removeClass('displayNone');
                    $('li[data-value="objectNum"]').removeClass('displayNone');
                } else {//hide
                    toHeight = 26;
                    $('li[data-value="worm"]').addClass('displayNone');
                    $('li[data-value="copy"]').addClass('displayNone');
                    $('li[data-value="remote"]').addClass('displayNone');
                    $('li[data-value="keepTime"]').addClass('displayNone');
                    $('li[data-value="capitcy"]').addClass('displayNone');
                    $('li[data-value="quota"]').addClass('displayNone');
                    $('li[data-value="capitcyQuota"]').addClass('displayNone');
                    $('li[data-value="objectNum"]').addClass('displayNone');

                    $('.advance-setting').css('min-height', 'auto');
                    $('.advance-setting').css('overflow', 'hidden');
                }
                setTimeout(function () {
                    parent.css('height', toHeight + 'px');
                    parent.children('header').children('i')[toHeight > 26 ? 'addClass' : 'removeClass']('active');
                }, 10);
                toHeight > 26 && setTimeout(function () {
                    parent.css('height', 'auto');
                    $('.advance-setting').css('overflow', 'visible');
                    if ($('.setting-pop').length) {
                        $('.advance-setting').css('min-height', '153px');
                    }
                }, 510);
            });
            clientDom.find('.setting-grid').ugrid({
                version: '2.0',
                pageShow: false,
                pageSize: 0,
                class: 'bucket_policy',
                data: pgridList || [],
                parameter: [
                    {key: 'Users', name: '授权用户',ellipsis: true},//
                    {key: 'Effect', name: '效果',ellipsis: true,formatter: true},
                    {key: 'Resource', name: '授权资源',ellipsis: true},
                    {key: 'Action', name: '动作',ellipsis: true},
                    {key: 'Condition', name: '条件',ellipsis: true,formatter: true},
                ],
                control: [
                    {key: 'create', text: '添加策略'}
                ],
                operate: [
                    {key: 'modify'},
                    {key: 'delete'}
                ],
                event: {
                    formatter: function (obj) {
                        var str = '';
                        switch (obj.key) {
                            case 'Effect':
                                str = obj.item.Effect === 'Allow'? '允许' :'拒绝';
                                break;
                            case 'Condition':
                                var Condition = [];
                                if(obj.item.Condition.length){
                                    Condition.push(obj.item.Condition[0].ConditionKey);
                                    Condition.push(obj.item.Condition[0].ConditionType);
                                    Condition.push('['+obj.item.Condition[0].ConditionValue+']');
                                    str = Condition.join(',');
                                }else {
                                    str = '-';
                                }
                                break;
                        }
                        return str;
                    },
                    modify: function (e, obj, that) {
                        o.getAddUserAuthority(obj.item);
                    },
                    delete: function (e, obj, that) {
                        that.delData(obj.index);
                        that.refresh();
                    },
                    create: function (e, obj, that) {
                        o.getAddUserAuthority();
                    },

                }
            });
            var $client = $('.advance-setting');
            $client.children('header').children('i').addClass('active');
            $client.css('height', 'auto');
        },
        getAddUserAuthority: function (pdata) {
            var str = pdata ? '修改策略' : '添加策略';
            $.upop({
                title: str,
                content: $('<div id="bucket_add_policy"></div>'),
                button: [{
                    key: "confirm",
                    text: "确定",
                    post: true
                }, {
                    key: "close",
                    text: "取消"
                }],
                event: [
                    {
                        key: 'confirm',
                        event: 'click',
                        action: function (e, data, upop) {
                            var policy = $('#bucket_add_policy').uform('getData');
                            if (!policy.flag) {
                                return;
                            }
                            //TODO
                            policy = policy['data'];
                            var _lis = $('#bucket_add_policy ul >li.followed');
                            var Condition = [];
                            for (var i = 0; i < _lis.length; i++) {
                                var ConditionKey = _lis.eq(i).find('.uform_info span').eq(0).text();
                                var ConditionType = _lis.eq(i).find('.uform_info span').eq(1).text();
                                var ConditionValue = _lis.eq(i).find('.uform_info span').eq(2).text() || _lis.eq(i).find('.input').val();
                                ConditionValue = (ConditionValue === '是')? true:((ConditionValue === '否')? false:ConditionValue);
                                ConditionValue = $.trim(ConditionValue.toString());
                                if(ConditionValue && ConditionValue !== '请选择时间') {
                                    Condition.push({
                                        'ConditionKey':ConditionKey,
                                        'ConditionType':ConditionType,
                                        'ConditionValue':ConditionValue
                                    })
                                }
                            }
                            
                            var policylist = $('.bucket_policy').ugrid('getData');
                            $grid = $('.bucket_policy');
                            var Resource = policy['Resource'].replace(/，/g, ',').split(',');
                            var Users = policy['Users'].replace(/，/g, ',').split(',');
                            for (var k = 0; k < Resource.length; k++) {
                                Resource[k] = $.trim(Resource[k]);
                            }
                            for (var k = 0; k < Users.length; k++) {
                                Users[k] = $.trim(Users[k]);
                            }
                            if (!pdata) {
                                $grid.ugrid('addData', [{
                                    Users: Users,
                                    Effect: policy['Effect'],
                                    Resource: Resource,
                                    Action: policy['Action'],
                                    Condition:Condition
                                }]);
                            } else {
                                pdata['Users'] = Users;
                                pdata['Effect'] = policy['Effect'];
                                pdata['Resource'] = Resource;
                                pdata['Action'] = policy['Action'];
                                pdata['Condition'] = Condition;
                                $grid.ugrid('refresh');
                            }
                            upop.remove();
                        }
                    }
                ]
            });
            o.policyForm(pdata);
        },
        policyForm:function(pdata){
            $('#bucket_add_policy').uform({
                params: [
                    {label: '授权用户', type: 'input', key: 'Users', required: true, regCoverFlag: true,
                        // tips:{text:'指定被授权的用户，“*” 表示所有用户,多个用户请使用英文逗号分隔'}
                        tips:{text:'指定被授权的用户，多个用户请使用英文逗号分隔'}
                    },
                    {label: '效果', type: 'radio', key: 'Effect', required: true,data: [{value: 'Allow', text: '允许', checked: true},{value: 'Deny', text: '拒绝'}],
                        tips:{text:'指定允许或拒绝动作中执行的操作'}
                    },
                    {label: '授权资源', type: 'input', key: 'Resource', required: true,
                        tips:{text:'指定权限作用的资源范围，“*” 表示所有资源，多个资源请使用英文逗号分隔，示例：testbucket, testbucket/*, testbucket/testfolder/object*'}
                    },
                    {
                        label: '动作',
                        type: 'multiple',
                        key: 'Action',
                        required: true,
                        data: o.actionList,
                        tips:{text:'指定支持执行的动作'}
                    },
                    {
                        label: 'Key',
                        type: 'select',
                        key: 'ConditionKey',
                        // required: true,
                        data: o.CKey, 
                    },
                    {
                        label: 'Condition',
                        type: 'select',
                        key: 'ConditionType',
                        // required: true,
                        data: o.CType['aws:CurrentTime'],
                        follow:'ConditionKey'
                    },
                    {
                        label: 'Value',
                        type: 'date',
                        time: true,
                        key: 'ConditionValue',
                        // required: true,
                        follow:'ConditionType'
                    },
                    {
                        key: 'ConditionIcon',
                        class: 'search_input',
                        type: 'input',
                        follow: 'ConditionValue',
                        icon: 'common_icon add custom_add'
                    }
                ],
                event:[
                    {
                        key: 'Users',
                        event: 'blur',
                        action: function (data, uform) {
                            // console.log(data,'Usersdata...');
                            var users = data.split(',');
                            if(users.length >1){
                                for(var i=0;i<users.length;i++){
                                    if(users[i].indexOf('*') > -1){
                                        this.pass = 'error';
                                        this.setRegErrorMsg('不支持输入通配符*');
                                        this.setRegStyle();
                                        return;
                                    }
                                }
                            }else {
                                if(users[0].indexOf('*') > -1){
                                    this.pass = 'error';
                                    this.setRegErrorMsg('不支持输入通配符*');
                                    this.setRegStyle();
                                    return;
                                }
                            }
                        }
                    }
                ],
                button: false
            });

            $('body').off('click', '#bucket_add_policy .list .uradio').on('click', '#bucket_add_policy .list .uradio', function (e) {
                // $(this).find('.radio').click();
                $('#bucket_add_policy .list .uradio').uradio('setChecked', false);
                $(this).uradio('setChecked', true);
                e.stopPropagation();
            });

            if(pdata){ //修改
                o.modifyPolicyForm(pdata);
            }else {
                var initAction = ['s3:DeleteObject','s3:GetObject','s3:ListBucket','s3:PutObject'];
                 // ['s3:DeleteObject','s3:GetObject','s3:ListBucket','s3:PutObject','s3:DeleteObjectVersion','s3:GetObjectVersion','s3:ListBucketVersions','s3:PutBucketVersioning']
                $('#bucket_add_policy').uform('setData',{"Action": initAction})
                var div = '<div class="ConditionTitle"><span>条件</span><span>Key</span><span>Condition</span><span>Value</span></div>';
                $(div).insertBefore($('#bucket_add_policy li[data-value="ConditionKey"]'));
            }
        },
        modifyPolicyForm:function(pdata){ //渲染修改policy页面，动态生成condition列表
            // console.log(pdata,'修改111');
            pdata.Effect =  (pdata.Effect === '允许')? 'Allow':(pdata.Effect === '拒绝')?'Deny' : pdata.Effect;
            $('#bucket_add_policy').uform('setData',{"Users": pdata.Users});
            $('#bucket_add_policy').uform('setData',{"Effect": pdata.Effect});
            $('#bucket_add_policy').uform('setData',{"Resource": pdata.Resource});
            $('#bucket_add_policy').uform('setData',{"Action": pdata.Action});

            if(pdata.Condition.length){
                $('#bucket_add_policy').uform('removeItems', ['ConditionKey','ConditionType','ConditionValue','ConditionIcon']);
                for(var i=0;i<pdata.Condition.length;i++){
                    var ConditionKey = 'ConditionKey';
                    var ConditionType = 'ConditionType';
                    var ConditionValue = 'ConditionValue';
                    var ConditionIcon = 'ConditionIcon';
                    var follow =  'ConditionKey';
                    if(i > 0){
                        ConditionKey = 'ConditionKey' + i;
                        ConditionType = 'ConditionType' + i;
                        ConditionValue = 'ConditionValue' + i;
                        ConditionIcon = 'ConditionIcon' + i;
                        $('#bucket_add_policy').uform('addList',
                            {
                                key: ConditionKey,
                                label: 'Key',
                                type: 'select',
                                // required: true,
                                data: o.CKey
                            }, follow
                        );
                        follow = ConditionKey;
                    }else {
                        $('#bucket_add_policy').uform('addList',
                            {
                                key: 'ConditionKey',
                                label: 'Key',
                                type: 'select',
                                // required: true,
                                data: o.CKey
                            }, 'Action'
                        );
                    }

                    $('#bucket_add_policy').uform('addList',
                        {
                            label: 'Condition',
                            type: 'select',
                            key: ConditionType,
                            // required: true,
                            data: o.CType[pdata.Condition[i]['ConditionKey']] || o.CType['aws:PrincipalType'],
                            follow: ConditionKey
                        }
                    );
                   
                    
                    if(pdata.Condition[i]['ConditionKey'] === 'aws:CurrentTime'){//Date
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'date',
                                time: true,
                                key: ConditionValue,
                                // required: true,
                                follow: ConditionType
                            }
                        );
                    }else if(pdata.Condition[i]['ConditionKey'] === 'aws:SecureTransport'){//bool
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'select',
                                key: ConditionValue,
                                // required: true,
                                follow: ConditionType,
                                data:[{text:'是',value:'true'},{text:'否',value:'false'}]
                            }
                        );
                    }else if(pdata.Condition[i]['ConditionKey'] === 'aws:EpochTime'){//Numeric
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'input',
                                kind:'positiveNum',
                                key: ConditionValue,
                                // required: true,
                                class: 'condition-input',
                                follow: ConditionType
                            }
                        );
                    }else if(pdata.Condition[i]['ConditionKey'] === 'aws:SourceIp'){//IP address
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'input',
                                kind:'IP',
                                key: ConditionValue,
                                class: 'condition-input',
                                // required: true,
                                follow: ConditionType
                            }
                        );
                    }else{ //string
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'input',
                                key: ConditionValue,
                                class: 'condition-input',
                                // required: true,
                                follow: ConditionType
                            }
                        );
                    }
                    if(i === 0){
                        $('#bucket_add_policy').uform('addList',
                            {
                                key: ConditionIcon,
                                class: 'search_input',
                                type: 'input',
                                follow: ConditionValue,
                                icon: 'common_icon add custom_add'
                            }
                        );
                    }else {
                        $('#bucket_add_policy').uform('addList',
                            {
                                key: ConditionIcon,
                                class: 'search_input',
                                type: 'input',
                                follow: ConditionValue,
                                icon: 'common_icon delete custom_delete'
                            }
                        );
                    }
                    o.index = i;
                    var keyObj = {},valueObj = {},typeObj = {};
                    valueObj[ConditionKey] = pdata.Condition[i]['ConditionKey'];
                    typeObj[ConditionType] = pdata.Condition[i]['ConditionType'];
                    $('#bucket_add_policy').uform('setData',valueObj);
                    $('#bucket_add_policy').uform('setData',typeObj);
                    if(pdata.Condition[i]['ConditionKey'] === 'aws:CurrentTime'){
                        valueObj[ConditionValue] = new Date(pdata.Condition[i]['ConditionValue']);
                        $('#bucket_add_policy').uform('setData',valueObj);
                    }else {
                        valueObj[ConditionValue] = pdata.Condition[i]['ConditionValue'];
                        $('#bucket_add_policy').uform('setData',valueObj);
                    }
                }
            }
            var div = '<div class="ConditionTitle"><span>条件</span><span>Key</span><span>Condition</span><span>Value</span></div>';
            $(div).insertBefore($('#bucket_add_policy li[data-value="ConditionKey"]'));
        },
        handleIcon:function(){
            // 动态添加列表
            $('body').off('click', '#bucket_add_policy .custom_add');
            $('body').on('click', '#bucket_add_policy .custom_add', function () {
                var follow;
                if (o.index === 0) {
                    follow = 'ConditionKey';
                } else {
                    follow = $('#bucket_add_policy').find('ul>li.mid:nth-last-child(1)').data('value');
                }
                o.index = o.index + 1;
                var ConditionKey = 'ConditionKey' + o.index;
                var ConditionType = 'ConditionType' + o.index;
                var ConditionValue = 'ConditionValue' + o.index;
                var ConditionIcon = 'ConditionIcon' + o.index;
                
                $('#bucket_add_policy').uform('addList',
                    {
                        key: ConditionKey,
                        label: 'Key',
                        type: 'select',
                        // required: true,
                        selected:false,
                        placeholder: '请选择键',
                        data: o.CKey
                    }, follow
                );
                $('#bucket_add_policy').uform('addList',
                    {
                        label: 'Condition',
                        type: 'select',
                        key: ConditionType,
                        // required: true,
                        selected:false,
                        placeholder: '请选择条件',
                        data: o.CType['aws:EpochTime'],
                        follow: ConditionKey
                    }
                );
                $('#bucket_add_policy').uform('addList',
                    {
                        label: 'Value',
                        type: 'input',
                        key: ConditionValue,
                        class: 'condition-input',
                        // required: true,
                        follow: ConditionType
                    }
                );
                $('#bucket_add_policy').uform('addList',
                    {
                        key: ConditionIcon,
                        class: 'search_input',
                        type: 'input',
                        follow: ConditionValue,
                        icon: 'common_icon delete custom_delete'
                    }
                );
            });
            $('body').on('click', '#bucket_add_policy .custom_delete', function () {
                var that = this;
                var value = $(this).closest('li.followed').data('value');
                var target = 'ConditionKey' + value.split('ConditionValue')[1];
                $('#bucket_add_policy').uform('removeItem', target);
            });

            //select变化input与select变换
            $('body').on('changed', '#bucket_add_policy .list li.followed .uselect', function () {
                var selected =$(this).uselect('getSelected');
                var arr = ['aws:CurrentTime','aws:EpochTime','aws:PrincipalType','aws:Referer','aws:SecureTransport','aws:SourceIp','aws:UserAgent','aws:username'];
                if(arr.indexOf(selected.value) > -1){
                    var ConditionType='',ConditionValue='';
                    var ConditionKey = $(this).parents('li.followed').data('value');
                    ConditionType = $(this).parents('li.followed').find('li.followed').data('value');
                    ConditionValue = $(this).parents('li.followed').find('li.followed li.followed').data('value');
                    ConditionIcon = $(this).parents('li.followed').find('li.followed li.followed li.follow').data('value');
                    
                    $('#bucket_add_policy').uform('removeItems',[ConditionType,ConditionValue,ConditionIcon]);
                    $('#bucket_add_policy').uform('addList',
                        {
                            label: 'Condition',
                            type: 'select',
                            key: ConditionType,
                            // required: true,
                            data: o.CType[selected.value] || o.CType['aws:PrincipalType'],
                            follow: ConditionKey
                        }
                    );
                    
                    if(selected.value === 'aws:CurrentTime'){//Date
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'date',
                                time: true,
                                key: ConditionValue,
                                class: 'condition-input',
                                // required: true,
                                follow: ConditionType
                            }
                        );
                    } else if(selected.value === 'aws:EpochTime'){//Numeric
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'input',
                                kind:'positiveNum',
                                key: ConditionValue,
                                class: 'condition-input',
                                // required: true,
                                follow: ConditionType
                            }
                        );
                    } else if(selected.value === 'aws:SecureTransport'){ //Bool
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'select',
                                key: ConditionValue,
                                class: 'condition-input',
                                // required: true,
                                follow: ConditionType,
                                data:[{text:'是',value:'true'},{text:'否',value:'false'}]
                            }
                        );

                    } else if(selected.value === 'aws:SourceIp'){//IP address
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'input',
                                kind:'IP',
                                key: ConditionValue,
                                class: 'condition-input',
                                // required: true,
                                follow: ConditionType
                            }
                        );
                    }else { //String
                        $('#bucket_add_policy').uform('addList',
                            {
                                label: 'Value',
                                type: 'input',
                                key: ConditionValue,
                                class: 'condition-input',
                                // required: true,
                                follow: ConditionType
                            }
                        );
                    }
                    if(ConditionType === 'ConditionType'){
                        $('#bucket_add_policy').uform('addList',
                            {
                                key: ConditionIcon,
                                class: 'search_input',
                                type: 'input',
                                follow: ConditionValue,
                                icon: 'common_icon add custom_add'
                            }
                        );
                    }else {
                        $('#bucket_add_policy').uform('addList',
                            {
                                key: ConditionIcon,
                                class: 'search_input',
                                type: 'input',
                                follow: ConditionValue,
                                icon: 'common_icon delete custom_delete'
                            }
                        );
                    }
                }
            });
        }
    };
    return o;
});